# Influencer Identification and Viral Marketing on Social Networks using Graph Neural Networks

**Problem statement.** To use Graph Neural Networks to predict user influence in a social network and select a small, diverse set of seed users that maximizes the reach of a viral marketing campaign under a fixed budget.

CA3 Graph-Based Case Study, Symbiosis Institute of Technology, Pune (Constituent of Symbiosis International (Deemed University)).

| Team member | PRN |
|---|---|
| Krisha Shah | 24070126512 |
| Janhavi Doijad | 23070126153 |
| Sahil Awatrami | 23070126112 |

The full write-up (18 pages, figures and tables) is in [`report/`](report/GNN_Influencer_Marketing_Case_Study.pdf).

## What we did

1. **Graph.** The SNAP ego-Facebook network: 4,039 users (nodes) and 88,234 friendships (edges).
2. **Ground truth.** Simulated word-of-mouth spreading with the independent-cascade (SIR) model at three share probabilities (p = 0.01, 0.02, 0.03). A user's influence is their expected reach as a single seed.
3. **Learning.** Trained GCN, GraphSAGE and GAT to predict each user's influence from three cheap structural features (log-degree, clustering coefficient, core number), using simulated labels for a sample of users. Evaluation is on held-out users with 5-fold cross-fitting.
4. **Our additions.** *RA-SAGE*: GraphSAGE trained with an extra pairwise ranking loss. *GNN-GDS*: seed selection that starts from the learned scores and discounts users close to seeds already chosen.
5. **Campaign test.** Compared seed sets from Random, Degree, PageRank, DegreeDiscount, naive top-k by GNN score, GNN-GDS and a simulation-based greedy reference, measured on 3,000 fresh simulations.

## Key results

Predicting single-user influence at p = 0.02 on held-out users (mean ± std over 5 folds; ρ is Spearman rank correlation with the 2,000-snapshot ground truth):

| Method | Spearman ρ | Top-5% precision | R² (log scale) |
|---|---|---|---|
| Degree | 0.811 ± 0.015 | 0.80 ± 0.02 | – |
| PageRank | 0.438 ± 0.035 | 0.17 ± 0.02 | – |
| k-core | 0.851 ± 0.011 | 0.86 ± 0.05 | – |
| 2-hop reach | 0.636 ± 0.011 | 0.03 ± 0.02 | – |
| GBM (hand-crafted) | 0.990 ± 0.001 | 0.95 ± 0.02 | 0.985 |
| MLP | 0.867 ± 0.007 | 0.93 ± 0.03 | 0.801 |
| GCN | 0.980 ± 0.001 | 0.77 ± 0.08 | 0.967 |
| GAT | 0.990 ± 0.001 | 0.91 ± 0.03 | 0.983 |
| GraphSAGE | 0.992 ± 0.000 | 0.90 ± 0.04 | 0.985 |
| RA-SAGE (ours) | 0.992 ± 0.000 | 0.92 ± 0.02 | 0.985 |

Expected campaign reach (users out of 4,039) at p = 0.02:

| Seed selection method | k = 5 | k = 10 | k = 20 | k = 50 |
|---|---|---|---|---|
| Random | 497 | 614 | 781 | 963 |
| Degree | 900 | 901 | 923 | 925 |
| PageRank | 900 | 934 | 971 | 1,045 |
| DegreeDiscount | 900 | 913 | 923 | 978 |
| Top-k by RA-SAGE score | 546 | 546 | 547 | 753 |
| **GNN-GDS (ours)** | 751 | 868 | 930 | 1,010 |
| Greedy on snapshots (reference) | 902 | 950 | 999 | 1,086 |

What the numbers say, including the unflattering parts:

- GNNs rank users far better than degree or PageRank (ρ ≈ 0.99 against 0.81 and 0.44), and about 20% labelled users are enough.
- Gradient boosting on hand-built features is almost as accurate (ρ = 0.990). The GNN advantage is not raw accuracy but that it works from three raw features without manual feature design.
- **The top-k trap.** Choosing the 20 highest-scored users reaches only 547 users, worse than 20 random users (781), because they all sit in one dense community. The diversity discount lifts this to 930 users (93% of the greedy reference).
- PageRank and the greedy reference are still stronger seed selectors than GNN-GDS on this network. The ranking-loss gain over plain GraphSAGE is small and mostly within one standard deviation.

## Mapping to the CA3 rubric

| Rubric criterion | CO | Marks | Report section | Code |
|---|---|---|---|---|
| Problem understanding and graph formulation | CO1 | 2 | Section 1 | `src/common.py` (snapshot-based diffusion model) |
| Selection of graph representation | CO2 | 1 | Section 2 | `src/models.py` (sparse message passing), `src/graph_stats.py` |
| Data preparation and implementation | CO3 | 2 | Section 3 | `src/setup_exp.py` (features, labels, folds, metrics) |
| Application of GNN architecture | CO4 | 2 | Section 4 | `src/models.py` (GCN, GraphSAGE, GAT, ranking loss), `src/run_main.py`, `src/run_gat.py` |
| Innovation and creativity | CO5 | 3 | Section 5 | RA-SAGE in `src/models.py`, GNN-GDS in `src/run_seeds.py` |
| Results interpretation and real-world impact | CO5 | 3 | Sections 6 and 7 | `src/figs_results.py`, `results/`, `figures/` |

## Repository layout

```
data/        facebook_combined.txt   edge list of the ego-Facebook network
src/         all code (see below)
results/     saved outputs of every experiment (pickle / JSON / npy)
figures/     every figure used in the report
report/      the Word and PDF case study
run_all.sh   re-runs everything from the raw edge list
```

| File | Purpose |
|---|---|
| `src/common.py` | graph loading, cascade snapshots (bond percolation), expected-reach computation |
| `src/models.py` | GCN, GraphSAGE and GAT layers written with sparse operations, ranking loss, training loop |
| `src/setup_exp.py` | features, folds, label generation, evaluation metrics |
| `src/run_main.py` | heuristics, GBM, MLP, GCN, GraphSAGE and RA-SAGE at three p values, ablations, label efficiency, transfer |
| `src/run_gat.py` | GAT at p = 0.02 (separate because it is about 7 times slower) |
| `src/run_seeds.py` | seed-set selection experiment and GNN-GDS |
| `src/graph_stats.py`, `src/layout.py` | network statistics and plotting layout |
| `src/fig_diagrams.py`, `src/figs_results.py`, `src/style.py` | figures (red-and-white theme) |
| `src/build_report.py` | builds the Word report from the saved results |

## Reproduce

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
./run_all.sh                 # about 25 minutes on 2 CPU cores
```

Run order if you want single stages: `graph_stats.py` → `run_main.py` → `run_gat.py` → `run_seeds.py` → `layout.py` → `fig_diagrams.py` → `figs_results.py` → `build_report.py` (all from inside `src/`). `run_seeds.py` needs the output of `run_main.py`. Random seeds are fixed. Tested with Python 3.13, PyTorch 2.14 (CPU), NumPy 2.5, SciPy 1.18, NetworkX 3.6, scikit-learn 1.9.

## Limitations

- Cascades are simulated with a uniform share probability, not observed from real sharing behaviour.
- ego-Facebook is a small, undirected, highly clustered friendship graph, not an influencer platform.
- With this simulator, exact greedy selection takes under a second on this network, so the surrogate is not faster here. Its value would appear with expensive diffusion models or much larger networks, which we did not test.
- One network only; GAT was run at p = 0.02 only.

## Data

`data/facebook_combined.txt` is the SNAP ego-Facebook edge list (4,039 nodes, 88,234 edges), copied from a public mirror of the SNAP file; it matches the published statistics.

> J. McAuley and J. Leskovec, "Learning to discover social circles in ego networks," NIPS 2012. Dataset: J. Leskovec and A. Krevl, SNAP Datasets, http://snap.stanford.edu/data
