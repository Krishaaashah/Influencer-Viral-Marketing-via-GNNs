import numpy as np, networkx as nx, scipy.sparse as sp
from paths import DATA
from scipy.sparse.csgraph import connected_components

def load_graph():
    G = nx.read_edgelist(str(DATA / 'facebook_combined.txt'), nodetype=int)
    G = nx.convert_node_labels_to_integers(G, ordering='sorted')
    return G

def edges_arr(G):
    return np.array(G.edges(), dtype=np.int64)

def snapshots(E, n, p, R, seed):
    """R bond-percolation snapshots (SIR / independent-cascade with one trial per friendship).
    Returns comp labels (R,n) int32 and comp sizes of each node's component (R,n) int32."""
    rng = np.random.default_rng(seed)
    m = len(E)
    labs = np.empty((R, n), dtype=np.int32)
    szs = np.empty((R, n), dtype=np.int32)
    for r in range(R):
        mask = rng.random(m) < p
        e = E[mask]
        A = sp.coo_matrix((np.ones(len(e), dtype=np.int8), (e[:, 0], e[:, 1])), shape=(n, n))
        _, lab = connected_components(A, directed=False)
        cnt = np.bincount(lab)
        labs[r] = lab
        szs[r] = cnt[lab]
    return labs, szs

def single_spread(szs):
    return szs.mean(axis=0)

def set_spread(labs, szs, S):
    """mean over snapshots of number of nodes reached from seed set S"""
    S = np.asarray(S)
    tot = 0.0
    for r in range(labs.shape[0]):
        l = labs[r, S]
        u, idx = np.unique(l, return_index=True)
        tot += szs[r, S[idx]].sum()
    return tot / labs.shape[0]
