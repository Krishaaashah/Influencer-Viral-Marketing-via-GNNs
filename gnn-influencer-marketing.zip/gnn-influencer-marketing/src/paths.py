"""Central place for every file location used by the project."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
RESULTS = ROOT / "results"
FIGS = ROOT / "figures"
REPORT = ROOT / "report"
FIGDIR = str(FIGS)          # string form for f-strings / savefig

for _d in (RESULTS, FIGS, REPORT):
    _d.mkdir(exist_ok=True)
