from paths import DATA, RESULTS, FIGS, REPORT, FIGDIR
from style import *
# ---------- Figure: end-to-end pipeline
fig, ax = plt.subplots(figsize=(7.0, 4.0)); ax.set_xlim(0, 10); ax.set_ylim(0, 6); ax.axis('off')
W = 2.0; xs = [0.1, 2.7, 5.3, 7.9]
top = ['1  Social network\nusers = nodes\nfriendships = edges', '2  Cascade simulation\nindependent-cascade\nsnapshots', '3  Influence labels\nexpected reach for a\nsample of users', '4  GNN training\nRA-SAGE learns to\npredict influence']
for i, t in enumerate(top): box(ax, xs[i], 3.7, W, 1.7, t, fc=RED if i == 3 else PALE, tc='white' if i == 3 else INK, fs=8.5)
for i in range(3): arrow(ax, (xs[i]+W+0.04, 4.55), (xs[i+1]-0.04, 4.55))
bot = [('5  Predict for all users\nfast surrogate replaces\nrepeated simulation', 7.9, PALE), ('6  Seed selection\ntop scores + diversity\ndiscount (GNN-GDS)', 5.3, RED), ('7  Campaign decision\nchoose k influencers,\nmeasure expected reach', 2.7, PALE)]
for t, x, c in bot: box(ax, x, 0.8, W, 1.7, t, fc=c, tc='white' if c == RED else INK, fs=8.5)
arrow(ax, (xs[3]+W/2, 3.66), (xs[3]+W/2, 2.55))
arrow(ax, (7.86, 1.65), (7.34, 1.65)); arrow(ax, (5.26, 1.65), (4.74, 1.65))
ax.text(0.1, 3.0, 'Offline stage (done once per network)', fontsize=9, color=DARK, style='italic')
ax.text(0.1, 1.65, 'Online stage\n(cheap enough to\nre-run for every\ncampaign)', fontsize=9, color=DARK, style='italic', va='center')
ax.plot([0.1, 9.9], [3.3, 3.3], color=LGRAY, lw=0.9, ls='--')
fig.savefig(f'{FIGDIR}/fig_pipeline.png'); plt.close(fig)

# ---------- Figure: architecture
fig, ax = plt.subplots(figsize=(7.0, 3.6)); ax.set_xlim(0, 12.4); ax.set_ylim(0, 6.4); ax.axis('off')
cx, cy = 1.7, 3.5
nb = [(0.8, 5.0), (2.7, 5.2), (0.7, 2.0), (2.8, 2.0), (1.7, 5.7)]
for (x, y) in nb: ax.plot([cx, x], [cy, y], color=MID, lw=1.2, zorder=1); ax.add_patch(Circle((x, y), 0.22, fc=LIGHT, ec=RED, lw=1.2, zorder=2))
ax.add_patch(Circle((cx, cy), 0.32, fc=RED, ec=DARK, lw=1.4, zorder=3))
ax.text(1.7, 0.95, 'user v and its friends', ha='center', fontsize=8.5, color=INK)
ax.text(1.7, 0.25, 'features: log degree,\nclustering, core number', ha='center', fontsize=8, color=GRAY)
bw = 1.9; bx = [3.7, 6.05, 8.4]
box(ax, bx[0], 2.7, bw, 1.6, 'SAGE layer 1\nmean of friends\n+ own features', fs=8.5); box(ax, bx[1], 2.7, bw, 1.6, 'SAGE layer 2\nadds friends-of-\nfriends signal', fs=8.5)
box(ax, bx[2], 2.7, 1.5, 1.6, 'MLP head\n64 → 64 → 1', fs=8.5); box(ax, 10.55, 2.9, 1.7, 1.2, 'predicted\ninfluence ŷ', fc=RED, tc='white', fs=8.5)
arrow(ax, (2.2, 3.5), (3.66, 3.5)); arrow(ax, (bx[0]+bw+0.04, 3.5), (bx[1]-0.04, 3.5)); arrow(ax, (bx[1]+bw+0.04, 3.5), (bx[2]-0.04, 3.5)); arrow(ax, (bx[2]+1.54, 3.5), (10.51, 3.5))
box(ax, 4.9, 0.3, 6.2, 0.95, 'Loss = MSE(ŷ, y) + λ · pairwise ranking loss', fc='white', ec=DARK, fs=8.5)
arrow(ax, (11.4, 2.86), (10.0, 1.3), color=DARK, rad=-0.2)
ax.text(6.0, 4.8, 'ReLU + dropout (0.1) after every layer', ha='center', fontsize=8, color=GRAY)
fig.savefig(f'{FIGDIR}/fig_architecture.png'); plt.close(fig)
print('ok')
