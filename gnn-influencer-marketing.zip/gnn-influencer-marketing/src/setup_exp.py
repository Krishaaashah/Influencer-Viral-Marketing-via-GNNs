from paths import DATA, RESULTS, FIGS, REPORT, FIGDIR
import warnings; warnings.filterwarnings('ignore')
from common import *; from models import *
import networkx as nx, time, json
from scipy.stats import spearmanr

P_LIST = [0.01, 0.02, 0.03]; P_MAIN = 0.02
G = load_graph(); n = G.number_of_nodes(); E = edges_arr(G)
deg = np.array([G.degree(i) for i in range(n)], float)
clu = nx.clustering(G); clu = np.array([clu[i] for i in range(n)])
core = nx.core_number(G); core = np.array([core[i] for i in range(n)], float)
A = sp.coo_matrix((np.ones(2*len(E)), (np.r_[E[:,0],E[:,1]], np.r_[E[:,1],E[:,0]])), shape=(n,n)).tocsr()
Xraw = np.stack([np.log1p(deg), clu, core/core.max()], 1)
X = torch.tensor((Xraw-Xraw.mean(0))/Xraw.std(0), dtype=torch.float32)
g = Graph(E, n)

def folds(k=5, seed=123):
    perm = np.random.default_rng(seed).permutation(n); parts = np.array_split(perm, k); out = []
    for i in range(k):
        te = parts[i]; rest = np.concatenate([parts[j] for j in range(k) if j != i])
        nv = int(0.1*len(rest)); out.append((rest[nv:], rest[:nv], te))   # train, val, test
    return out

def get_labels(p):
    labs, szs = snapshots(E, n, p, 300, 11); y_noisy = np.log1p(single_spread(szs))
    labs2, szs2 = snapshots(E, n, p, 2000, 22); y_clean = np.log1p(single_spread(szs2))
    return y_noisy, y_clean, single_spread(szs2)

def metrics(pred, ytrue):
    rho = spearmanr(pred, ytrue)[0]
    k = max(1, int(0.05*len(pred))); top = np.argsort(-pred)[:k]; tt = np.argsort(-ytrue)[:k]
    prec = len(set(top) & set(tt))/k
    return rho, prec

def r2(pred, ytrue):
    return 1 - ((pred-ytrue)**2).sum()/((ytrue-ytrue.mean())**2).sum()
