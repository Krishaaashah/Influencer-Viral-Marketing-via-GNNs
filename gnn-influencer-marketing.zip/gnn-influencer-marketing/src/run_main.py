from paths import DATA, RESULTS, FIGS, REPORT, FIGDIR
from setup_exp import *
from sklearn.ensemble import HistGradientBoostingRegressor
import pickle
T0 = time.time()
# ---- handcrafted features for GBM and heuristics
pr = nx.pagerank(G); pr = np.array([pr[i] for i in range(n)])
nbr_deg = np.asarray(A@deg).ravel()/np.maximum(deg,1)
A2 = ((A@A + A) > 0).astype(np.int8); hop2 = np.asarray(A2.sum(1)).ravel()-1
Hand = np.stack([deg, np.log1p(deg), clu, core, pr, nbr_deg, hop2], 1)
heur = {'Degree': deg, 'PageRank': pr, 'k-core': core + 1e-3*deg, '2-hop reach': hop2.astype(float)}
FO = folds()
results = {}; oof_store = {}; timing = {}

def run_model(name, p, y_noisy, y_clean, kind=None, lam=0.0, layers=2):
    rows = []; oof = np.zeros(n); t_tr = 0
    for fi, (tr, va, te) in enumerate(FO):
        mu, sd = y_noisy[tr].mean(), y_noisy[tr].std(); yt = torch.tensor((y_noisy-mu)/sd, dtype=torch.float32)
        t = time.time()
        if name == 'GBM':
            m = HistGradientBoostingRegressor(max_iter=300, learning_rate=0.05, random_state=fi).fit(Hand[tr], y_noisy[tr]); o = m.predict(Hand)
        else:
            net, h = train_model(kind, X, g, yt, tr, va, layers=layers, lam=lam, seed=fi)
            with torch.no_grad(): o = net(X, g).numpy()*sd + mu
        t_tr += time.time()-t
        oof[te] = o[te]; rho, prec = metrics(o[te], y_clean[te]); rows.append(dict(rho=rho, prec=prec, r2=r2(o[te], y_clean[te])))
    return rows, oof, t_tr/len(FO)

def summarize(rows):
    return {k: (float(np.mean([r[k] for r in rows])), float(np.std([r[k] for r in rows]))) for k in ['rho','prec','r2']}

LAB = {}
for p in P_LIST:
    t = time.time(); y_noisy, y_clean, spread_clean = get_labels(p); timing[f'labels_p{p}'] = time.time()-t
    LAB[p] = (y_noisy, y_clean, spread_clean)
    results[p] = {}
    # heuristics
    for hn, hv in heur.items():
        rows = []
        for tr, va, te in FO:
            rho, prec = metrics(hv[te], y_clean[te]); rows.append(dict(rho=rho, prec=prec, r2=float('nan')))
        results[p][hn] = summarize(rows) | {'kind': 'heuristic'}
    cfg = [('MLP', 'MLP', 0.0), ('GCN', 'GCN', 0.0), ('GraphSAGE', 'SAGE', 0.0), ('RA-SAGE (ours)', 'SAGE', 0.5)]
    rows, oof, tt = run_model('GBM', p, y_noisy, y_clean); results[p]['GBM (hand-crafted)'] = summarize(rows) | {'kind': 'ml', 'train_s': tt}; oof_store[(p, 'GBM')] = oof
    for nm, kind, lam in cfg:
        rows, oof, tt = run_model(nm, p, y_noisy, y_clean, kind=kind, lam=lam)
        results[p][nm] = summarize(rows) | {'kind': 'gnn' if kind != 'MLP' else 'ml', 'train_s': tt}; oof_store[(p, nm)] = oof
        print(p, nm, results[p][nm], flush=True)
    print('p', p, 'done', round(time.time()-T0), flush=True)
pickle.dump((results, oof_store, LAB), open(RESULTS / 'main_stage1.pkl', 'wb'))

# ---- ablations at P_MAIN
y_noisy, y_clean, _ = LAB[P_MAIN]; abl = {}
for nm, kind, lam, layers in [('GCN + rank loss', 'GCN', 0.5, 2), ('RA-SAGE 1 layer', 'SAGE', 0.5, 1), ('RA-SAGE 3 layers', 'SAGE', 0.5, 3),
                              ('SAGE + rank (lambda=0.25)', 'SAGE', 0.25, 2), ('SAGE + rank (lambda=1)', 'SAGE', 1.0, 2)]:
    rows, oof, tt = run_model(nm, P_MAIN, y_noisy, y_clean, kind=kind, lam=lam, layers=layers); abl[nm] = summarize(rows); print('abl', nm, abl[nm], flush=True)
pickle.dump(abl, open(RESULTS / 'ablations.pkl', 'wb'))

# ---- label efficiency: how many nodes need simulated labels?
fr = {}
tr0, va0, te0 = FO[0]; pool = np.concatenate([tr0, va0])
for frac in [0.02, 0.05, 0.10, 0.20, 0.40, 0.70]:
    vals = []
    for rep in range(2):
        rng = np.random.default_rng(100+rep); sub = rng.permutation(pool)[:max(30, int(frac*n))]
        nv = max(10, int(0.15*len(sub))); va_s, tr_s = sub[:nv], sub[nv:]
        mu, sd = y_noisy[tr_s].mean(), y_noisy[tr_s].std(); yt = torch.tensor((y_noisy-mu)/sd, dtype=torch.float32)
        net, h = train_model('SAGE', X, g, yt, tr_s, va_s, lam=0.5, seed=rep)
        with torch.no_grad(): o = net(X, g).numpy()
        vals.append(metrics(o[te0], y_clean[te0])[0])
    fr[frac] = (float(np.mean(vals)), float(np.std(vals))); print('frac', frac, fr[frac], flush=True)
pickle.dump(fr, open(RESULTS / 'label_eff.pkl', 'wb'))

# ---- cross-p generalisation
cross = {}
for pa in P_LIST:
    for pb in P_LIST:
        cross[(pa, pb)] = float(spearmanr(oof_store[(pa, 'RA-SAGE (ours)')], LAB[pb][1])[0])
pickle.dump(cross, open(RESULTS / 'cross_p.pkl', 'wb')); print('cross', cross, flush=True)
print('ALL DONE', round(time.time()-T0))
