from paths import DATA, RESULTS, FIGS, REPORT, FIGDIR
from setup_exp import *
y_noisy, y_clean, _ = get_labels(P_MAIN)
res = []; oof = np.zeros(n); t0 = time.time()
for fi, (tr, va, te) in enumerate(folds()):
    mu, sd = y_noisy[tr].mean(), y_noisy[tr].std(); yt = torch.tensor((y_noisy-mu)/sd, dtype=torch.float32)
    t = time.time(); net, h = train_model('GAT', X, g, yt, tr, va, epochs=150, patience=30, seed=fi)
    with torch.no_grad(): o = net(X, g).numpy()*sd+mu
    oof[te] = o[te]; rho, prec = metrics(o[te], y_clean[te]); res.append(dict(fold=fi, rho=rho, prec=prec, r2=r2(o[te], y_clean[te]), epochs=len(h), secs=time.time()-t))
    print(res[-1], flush=True)
np.save(RESULTS / 'oof_GAT_p0.02.npy', oof); json.dump(res, open(RESULTS / 'gat_results.json','w'))
print('done', time.time()-t0)
