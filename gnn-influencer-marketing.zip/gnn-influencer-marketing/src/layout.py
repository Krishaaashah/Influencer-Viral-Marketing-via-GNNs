from paths import DATA, RESULTS, FIGS, REPORT, FIGDIR
from common import *; import networkx as nx, numpy as np, time
G = load_graph(); t = time.time()
pos = nx.spring_layout(G, k=0.12, iterations=80, seed=3)
np.save(RESULTS / 'pos.npy', np.array([pos[i] for i in range(G.number_of_nodes())])); print('layout', time.time()-t)
