"""Structural statistics of the ego-Facebook network -> results/stats.json (Table 3 of the report)."""
import json
import numpy as np, networkx as nx
from paths import RESULTS
from common import load_graph

G = load_graph(); n = G.number_of_nodes()
d = np.array([G.degree(i) for i in range(n)])
comms = nx.community.louvain_communities(G, seed=1)
stats = dict(
    n=n, m=G.number_of_edges(), density=nx.density(G), avg_deg=float(d.mean()), med_deg=float(np.median(d)),
    max_deg=int(d.max()), min_deg=int(d.min()), clust=nx.average_clustering(G), trans=nx.transitivity(G),
    diam=nx.diameter(G), avg_path=nx.average_shortest_path_length(G), ncomm=len(comms),
    modularity=nx.community.modularity(G, comms), Tc=float(d.mean() / ((d ** 2).mean() - d.mean())),
    top1pct_share=float(np.sort(d)[::-1][:int(0.01 * n)].sum() / d.sum()), core_max=int(max(nx.core_number(G).values())),
)
json.dump(stats, open(RESULTS / 'stats.json', 'w'), indent=2)
print(stats)
