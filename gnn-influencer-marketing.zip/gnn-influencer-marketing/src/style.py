import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle
DARK, RED, MID, LIGHT, PALE = '#7A0019', '#C8102E', '#E8737F', '#F6D0D4', '#FCEDEE'
GRAY, LGRAY, INK = '#6B6B6B', '#D9D9D9', '#222222'
plt.rcParams.update({'font.family': 'serif', 'font.serif': ['Liberation Serif', 'Times New Roman', 'DejaVu Serif'], 'font.size': 10,
    'axes.edgecolor': INK, 'axes.linewidth': 0.8, 'axes.spines.top': False, 'axes.spines.right': False, 'axes.labelcolor': INK,
    'xtick.color': INK, 'ytick.color': INK, 'figure.facecolor': 'white', 'axes.facecolor': 'white', 'savefig.dpi': 220, 'savefig.bbox': 'tight'})
def box(ax, x, y, w, h, text, fc=PALE, ec=RED, tc=INK, fs=9.5, bold=False, lw=1.4):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.02,rounding_size=0.08', fc=fc, ec=ec, lw=lw))
    ax.text(x+w/2, y+h/2, text, ha='center', va='center', fontsize=fs, color=tc, fontweight='bold' if bold else 'normal', linespacing=1.25)
def arrow(ax, p, q, color=RED, lw=1.6, rad=0.0):
    ax.add_patch(FancyArrowPatch(p, q, arrowstyle='-|>', mutation_scale=13, color=color, lw=lw, connectionstyle=f'arc3,rad={rad}'))
