import numpy as np, torch, torch.nn as nn, torch.nn.functional as F
from scipy.stats import spearmanr
torch.set_num_threads(1)

class Graph:
    def __init__(self, E, n):
        src = np.concatenate([E[:,0], E[:,1]]); dst = np.concatenate([E[:,1], E[:,0]])
        loops = np.arange(n)
        self.n = n
        self.src_sl = torch.tensor(np.concatenate([src, loops])); self.dst_sl = torch.tensor(np.concatenate([dst, loops]))
        deg = np.bincount(dst, minlength=n).astype(np.float32)
        deg_sl = deg + 1
        w_gcn = 1.0/np.sqrt(deg_sl[self.src_sl.numpy()]*deg_sl[self.dst_sl.numpy()])
        self.A_gcn = torch.sparse_coo_tensor(torch.stack([self.dst_sl, self.src_sl]), torch.tensor(w_gcn, dtype=torch.float32), (n,n)).coalesce()
        w_mean = 1.0/np.maximum(deg[dst],1)
        self.A_mean = torch.sparse_coo_tensor(torch.stack([torch.tensor(dst), torch.tensor(src)]), torch.tensor(w_mean, dtype=torch.float32), (n,n)).coalesce()

class GATLayer(nn.Module):
    def __init__(self, i, o, heads=4):
        super().__init__()
        self.h = heads; self.d = o//heads
        self.W = nn.Linear(i, o, bias=False)
        self.a_s = nn.Parameter(torch.randn(heads, self.d)*0.1); self.a_d = nn.Parameter(torch.randn(heads, self.d)*0.1)
    def forward(self, x, g):
        n = x.shape[0]
        Wh = self.W(x).view(n, self.h, self.d)
        es = (Wh*self.a_s).sum(-1); ed = (Wh*self.a_d).sum(-1)
        e = F.leaky_relu(es[g.src_sl] + ed[g.dst_sl], 0.2)             # (E,h)
        emax = torch.full((n, self.h), -1e9).scatter_reduce(0, g.dst_sl[:,None].expand_as(e), e, 'amax', include_self=True)
        ex = torch.exp(e - emax[g.dst_sl])
        den = torch.zeros(n, self.h).index_add_(0, g.dst_sl, ex)
        alpha = ex/den[g.dst_sl]
        out = torch.zeros(n, self.h, self.d).index_add_(0, g.dst_sl, alpha[...,None]*Wh[g.src_sl])
        return out.reshape(n, -1)

class Net(nn.Module):
    def __init__(self, kind, in_dim, hid=64, layers=2, drop=0.1):
        super().__init__()
        self.kind = kind; self.drop = drop; self.layers = nn.ModuleList(); self.self_lin = nn.ModuleList()
        d = in_dim
        for _ in range(layers):
            if kind == 'GCN': self.layers.append(nn.Linear(d, hid))
            elif kind == 'SAGE': self.layers.append(nn.Linear(d, hid)); self.self_lin.append(nn.Linear(d, hid, bias=False))
            elif kind == 'GAT': self.layers.append(GATLayer(d, hid))
            elif kind == 'MLP': self.layers.append(nn.Linear(d, hid))
            d = hid
        self.head = nn.Sequential(nn.Linear(hid, hid), nn.ReLU(), nn.Linear(hid, 1))
    def forward(self, x, g):
        h = x
        for i, L in enumerate(self.layers):
            if self.kind == 'GCN': h = torch.sparse.mm(g.A_gcn, L(h))
            elif self.kind == 'SAGE': h = L(torch.sparse.mm(g.A_mean, h)) + self.self_lin[i](h)
            elif self.kind == 'GAT': h = L(h, g)
            else: h = L(h)
            h = F.relu(h) if self.kind != 'GAT' else F.elu(h)
            h = F.dropout(h, self.drop, self.training)
        return self.head(h).squeeze(-1)

def rank_loss(pred, y, idx, npairs=20000, margin=0.05, gen=None):
    a = idx[torch.randint(len(idx), (npairs,), generator=gen)]; b = idx[torch.randint(len(idx), (npairs,), generator=gen)]
    dy = y[a]-y[b]; keep = dy.abs() > margin
    if keep.sum()==0: return pred.sum()*0
    s = torch.sign(dy[keep])*(pred[a][keep]-pred[b][keep])
    return F.softplus(-s).mean()

def train_model(kind, X, g, y, tr, va, layers=2, hid=64, lam=0.0, epochs=250, patience=40, lr=0.01, seed=0, log=False):
    torch.manual_seed(seed); gen = torch.Generator().manual_seed(seed)
    net = Net(kind, X.shape[1], hid, layers); opt = torch.optim.Adam(net.parameters(), lr=lr, weight_decay=5e-4)
    tr_t = torch.tensor(tr); va_t = torch.tensor(va)
    best, best_state, bad, hist = -1, None, 0, []
    for ep in range(epochs):
        net.train(); opt.zero_grad()
        out = net(X, g)
        loss = F.mse_loss(out[tr_t], y[tr_t])
        if lam > 0: loss = loss + lam*rank_loss(out, y, tr_t, gen=gen)
        loss.backward(); opt.step()
        net.eval()
        with torch.no_grad():
            o = net(X, g)
            vs = spearmanr(o[va_t].numpy(), y[va_t].numpy())[0]
            vl = F.mse_loss(o[va_t], y[va_t]).item()
        hist.append((loss.item(), vl, vs))
        if vs > best + 1e-4: best, bad = vs, 0; best_state = {k: v.clone() for k, v in net.state_dict().items()}
        else:
            bad += 1
            if bad >= patience: break
    net.load_state_dict(best_state); net.eval()
    return net, hist
