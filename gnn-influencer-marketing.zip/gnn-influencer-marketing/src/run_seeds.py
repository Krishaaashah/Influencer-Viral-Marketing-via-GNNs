from paths import DATA, RESULTS, FIGS, REPORT, FIGDIR
from setup_exp import *
import pickle, itertools
results, oof_store, LAB = pickle.load(open(RESULTS / 'main_stage1.pkl','rb'))
pr = nx.pagerank(G); pr = np.array([pr[i] for i in range(n)])
K_LIST = [5, 10, 20, 30, 50]; KMAX = max(K_LIST)
A1 = A.copy(); A1.data[:] = 1

def top_k(score, k): return list(np.argsort(-score)[:k])

def degree_discount(p, k):
    dd = deg.copy(); t = np.zeros(n); sel = []; chosen = np.zeros(n, bool)
    for _ in range(k):
        u = int(np.argmax(np.where(chosen, -np.inf, dd))); sel.append(u); chosen[u] = True
        for v in G.neighbors(u):
            if not chosen[v]:
                t[v] += 1; dd[v] = deg[v] - 2*t[v] - (deg[v]-t[v])*t[v]*p
    return sel

def gds(score, k, f1, f2):
    """GNN-guided diversity-aware selection: learned influence scores, discounted near already chosen seeds"""
    a1 = np.zeros(n); a2 = np.zeros(n); chosen = np.zeros(n, bool); sel = []
    for _ in range(k):
        s = score*(f1**a1)*(f2**a2); s[chosen] = -np.inf
        u = int(np.argmax(s)); sel.append(u); chosen[u] = True
        n1 = A1[u].indices; reach2 = np.unique(A1[n1].indices); n2 = np.setdiff1d(reach2, np.r_[n1, u])
        a1[n1] += 1; a2[n2] += 1
    return sel

def static_greedy(labs, szs, k):
    R = labs.shape[0]; covered = np.zeros((R, n), bool); rows = np.arange(R)[:, None]; sel = []
    for _ in range(k):
        gain = (szs*(~covered[rows, labs])).mean(0); gain[sel] = -1
        u = int(np.argmax(gain)); sel.append(u); covered[np.arange(R), labs[:, u]] = True
    return sel

out = {}
for p in P_LIST:
    labs_g, szs_g = snapshots(E, n, p, 500, 33)       # greedy (reference) snapshots
    labs_t, szs_t = snapshots(E, n, p, 500, 55)       # tuning snapshots for GDS discounts
    labs_e, szs_e = snapshots(E, n, p, 3000, 44)      # fresh evaluation snapshots
    score = np.expm1(oof_store[(p, 'RA-SAGE (ours)')]); score_gnn_plain = np.expm1(oof_store[(p, 'GraphSAGE')])
    GRID = list(itertools.product([1.0, 0.8, 0.6, 0.4, 0.2, 0.1, 0.05], [1.0, 0.9, 0.8, 0.7, 0.6, 0.5]))
    bp_k = {}
    for k in K_LIST:   # tune discounts per budget on separate tuning snapshots
        best, bp = -1, None
        for f1, f2 in GRID:
            v = set_spread(labs_t, szs_t, gds(score, k, f1, f2))
            if v > best: best, bp = v, (f1, f2)
        bp_k[k] = bp
    print('p', p, 'GDS params per k', bp_k, flush=True)
    out[p] = {'gds_params': bp_k, 'spread': {}, 'sets': {}}
    tg = time.time(); greedy_full = static_greedy(labs_g, szs_g, KMAX); t_greedy = time.time()-tg
    t_gds = time.time(); _ = gds(score, KMAX, *bp_k[KMAX]); t_gds = time.time()-t_gds
    out[p]['times'] = {'greedy_s': t_greedy, 'gds_s': t_gds}
    rng = np.random.default_rng(7)
    for k in K_LIST:
        sets = {'Random': None, 'Degree': top_k(deg, k), 'PageRank': top_k(pr, k), 'Degree-Discount': degree_discount(p, k),
                'GNN top-k': top_k(score_gnn_plain, k), 'RA-SAGE top-k': top_k(score, k), 'GNN-GDS (ours)': gds(score, k, *bp_k[k]), 'Greedy (reference)': greedy_full[:k]}
        sp_ = {}
        for nm, S in sets.items():
            if nm == 'Random': sp_[nm] = float(np.mean([set_spread(labs_e, szs_e[:, :], rng.choice(n, k, replace=False)) for _ in range(20)]))
            else: sp_[nm] = float(set_spread(labs_e, szs_e, S))
        out[p]['spread'][k] = sp_; out[p]['sets'][k] = {nm: [int(x) for x in S] for nm, S in sets.items() if S is not None}
        print(p, k, {a: round(b, 1) for a, b in sp_.items()}, flush=True)
pickle.dump(out, open(RESULTS / 'seeds.pkl', 'wb')); print('SEEDS DONE')
