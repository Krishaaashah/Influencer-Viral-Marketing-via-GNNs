from paths import DATA, RESULTS, FIGS, REPORT, FIGDIR
from style import *
import pickle, json, numpy as np, networkx as nx
from matplotlib.lines import Line2D
from matplotlib.colors import LinearSegmentedColormap
from common import *
results, oof, LAB = pickle.load(open(RESULTS / 'main_stage1.pkl', 'rb')); seeds = pickle.load(open(RESULTS / 'seeds.pkl', 'rb'))
abl = pickle.load(open(RESULTS / 'ablations.pkl', 'rb')); labeff = pickle.load(open(RESULTS / 'label_eff.pkl', 'rb')); cross = pickle.load(open(RESULTS / 'cross_p.pkl', 'rb'))
gat = json.load(open(RESULTS / 'gat_results.json')); G = load_graph(); n = G.number_of_nodes(); pos = np.load(RESULTS / 'pos.npy')
deg = np.array([G.degree(i) for i in range(n)], float); P = 0.02
cmap_red = LinearSegmentedColormap.from_list('wr', ['#FFFFFF', '#F6D0D4', '#E8737F', '#C8102E', '#7A0019'])
y_noisy, y_clean, sp = LAB[P]
gat_rho = (float(np.mean([r['rho'] for r in gat])), float(np.std([r['rho'] for r in gat])))

# ---- F: network, naive top-k vs GDS
S = seeds[P]['sets'][20]
fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.8))
for ax, key, title in [(axs[0], 'RA-SAGE top-k', '(a) Top-20 by predicted influence'), (axs[1], 'GNN-GDS (ours)', '(b) Top-20 with diversity discount')]:
    ax.set_aspect('equal'); ax.axis('off')
    for u, v in G.edges(): pass
    segs = np.array([[pos[u], pos[v]] for u, v in G.edges()])
    from matplotlib.collections import LineCollection
    ax.add_collection(LineCollection(segs, colors='#EEE0E1', linewidths=0.15, zorder=1))
    order = np.argsort(sp)
    ax.scatter(pos[order, 0], pos[order, 1], c=sp[order], cmap=cmap_red, s=3.5, linewidths=0, zorder=2, vmin=0, vmax=sp.max())
    ax.scatter(pos[S[key], 0], pos[S[key], 1], marker='*', s=95, c=RED, edgecolors=INK, linewidths=0.7, zorder=4)
    ax.set_title(title, fontsize=9.5, color=INK); ax.autoscale()
    reach = seeds[P]['spread'][20]['RA-SAGE top-k' if key == 'RA-SAGE top-k' else key]
    ax.text(0.5, -0.04, f'expected reach: {reach:,.0f} users ({100*reach/n:.0f}%)', transform=ax.transAxes, ha='center', fontsize=8.5, color=DARK)
sm = plt.cm.ScalarMappable(cmap=cmap_red, norm=plt.Normalize(0, sp.max())); cb = fig.colorbar(sm, ax=axs, shrink=0.55, pad=0.02, aspect=18); cb.set_label('single-user expected reach', fontsize=8.5); cb.outline.set_visible(False)
fig.savefig(f'{FIGDIR}/fig_network.png'); plt.close(fig)

# ---- F: data profile
fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.9))
vals, cnts = np.unique(deg, return_counts=True)
axs[0].scatter(vals, cnts, s=9, c=RED, alpha=0.8, linewidths=0); axs[0].set_xscale('log'); axs[0].set_yscale('log')
axs[0].set_xlabel('number of friends (degree)'); axs[0].set_ylabel('number of users'); axs[0].set_title('(a) Degree distribution', fontsize=9.5)
hb = axs[1].hexbin(deg, sp, gridsize=38, xscale='log', cmap=cmap_red, mincnt=1, bins='log', linewidths=0.1)
axs[1].set_xlabel('number of friends (degree)'); axs[1].set_ylabel('expected reach (users)'); axs[1].set_title('(b) Reach vs. degree (p = 0.02)', fontsize=9.5)
cb = fig.colorbar(hb, ax=axs[1], pad=0.02); cb.set_label('users (log)', fontsize=8); cb.outline.set_visible(False)
fig.tight_layout(); fig.savefig(f'{FIGDIR}/fig_profile.png'); plt.close(fig)

# ---- F: model comparison (dot plot)
order = ['Degree', 'PageRank', 'k-core', '2-hop reach', 'GBM (hand-crafted)', 'MLP', 'GCN', 'GAT', 'GraphSAGE', 'RA-SAGE (ours)']
vals = {m: results[P][m]['rho'] for m in order if m != 'GAT'}; vals['GAT'] = gat_rho
order.sort(key=lambda m: vals[m][0])
fig, ax = plt.subplots(figsize=(6.4, 3.6))
for i, m in enumerate(order):
    c = RED if 'ours' in m else (MID if m in ('GCN', 'GAT', 'GraphSAGE') else GRAY)
    ax.plot([0.4, vals[m][0]], [i, i], color=LGRAY, lw=1, zorder=1)
    ax.errorbar(vals[m][0], i, xerr=vals[m][1], fmt='o', color=c, ms=7.5, capsize=3, lw=1.3, zorder=3, mec=DARK if 'ours' in m else c)
    if vals[m][0] < 0.95: ax.text(vals[m][0]+0.012, i+0.28, f'{vals[m][0]:.3f}', ha='left', va='center', fontsize=8.5, color=INK)
    else: ax.text(vals[m][0]-0.01, i+0.28, f'{vals[m][0]:.3f}', ha='right', va='center', fontsize=8.5, color=INK)
ax.set_yticks(range(len(order))); ax.set_yticklabels(order); ax.set_xlim(0.4, 1.0); ax.set_xlabel('Spearman rank correlation with true influence (held-out users, 5 folds)')
for t in ax.get_yticklabels():
    if 'ours' in t.get_text(): t.set_fontweight('bold'); t.set_color(DARK)
ax.legend(handles=[Line2D([], [], marker='o', ls='', color=GRAY, label='heuristic / classical ML'), Line2D([], [], marker='o', ls='', color=MID, label='GNN baselines'), Line2D([], [], marker='o', ls='', color=RED, label='proposed (rank-aware)')], loc='lower right', frameon=False, fontsize=8)
fig.savefig(f'{FIGDIR}/fig_models.png'); plt.close(fig)

# ---- F: predicted vs true
o = oof[(P, 'RA-SAGE (ours)')]
fig, ax = plt.subplots(figsize=(4.4, 3.8))
hb = ax.hexbin(np.expm1(y_clean), np.expm1(o), gridsize=45, cmap=cmap_red, mincnt=1, bins='log', xscale='log', yscale='log', linewidths=0.1)
lim = [1, 1500]; ax.plot(lim, lim, color=INK, lw=0.9, ls='--'); ax.set_xlim(lim); ax.set_ylim(lim)
ax.set_xlabel('true expected reach (simulated, users)'); ax.set_ylabel('predicted expected reach (users)')
cb = fig.colorbar(hb, ax=ax, pad=0.02); cb.set_label('users (log)', fontsize=8); cb.outline.set_visible(False)
fig.savefig(f'{FIGDIR}/fig_scatter.png'); plt.close(fig)

# ---- F: seed selection curves
fig, axs = plt.subplots(1, 3, figsize=(7.3, 2.9), sharey=False)
sty = {'Greedy (reference)': (DARK, '-', 's', 1.6), 'PageRank': (INK, '--', '^', 1.2), 'Degree-Discount': (GRAY, '-.', 'v', 1.2), 'GNN-GDS (ours)': (RED, '-', 'o', 2.2), 'RA-SAGE top-k': (MID, ':', 'D', 1.5), 'Random': (LGRAY, '-', None, 1.2)}
for ax, p in zip(axs, [0.01, 0.02, 0.03]):
    ks = sorted(seeds[p]['spread'])
    for m, (c, ls, mk, lw) in sty.items():
        ax.plot(ks, [100*seeds[p]['spread'][k][m]/n for k in ks], color=c, ls=ls, marker=mk, ms=4.5, lw=lw, label=m)
    ax.set_title(f'p = {p}', fontsize=9.5); ax.set_xlabel('number of seed users (k)')
axs[0].set_ylabel('expected reach (% of network)')
h, l = axs[0].get_legend_handles_labels(); fig.legend(h, l, loc='lower center', ncol=3, frameon=False, fontsize=8, bbox_to_anchor=(0.5, -0.16))
fig.tight_layout(); fig.savefig(f'{FIGDIR}/fig_seeds.png'); plt.close(fig)

# ---- F: cross-p heatmap
ps = [0.01, 0.02, 0.03]; M = np.array([[cross[(a, b)] for b in ps] for a in ps])
fig, ax = plt.subplots(figsize=(3.6, 3.0)); im = ax.imshow(M, cmap=cmap_red, vmin=0.7, vmax=1.0)
for i in range(3):
    for j in range(3): ax.text(j, i, f'{M[i, j]:.3f}', ha='center', va='center', fontsize=9, color='white' if M[i, j] > 0.92 else INK)
ax.set_xticks(range(3)); ax.set_yticks(range(3)); ax.set_xticklabels(ps); ax.set_yticklabels(ps); ax.set_xlabel('evaluated at p'); ax.set_ylabel('trained at p')
for s_ in ax.spines.values(): s_.set_visible(False)
ax.tick_params(length=0); fig.savefig(f'{FIGDIR}/fig_crossp.png'); plt.close(fig)

# ---- F: ablation + label efficiency
fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.0), gridspec_kw={'width_ratios': [1.15, 1]})
rows = [('GraphSAGE (2 layers)', results[P]['GraphSAGE']['rho']), ('RA-SAGE, 1 layer', abl['RA-SAGE 1 layer']), ('RA-SAGE, 2 layers (λ=0.5)', results[P]['RA-SAGE (ours)']['rho']),
        ('RA-SAGE, 3 layers', abl['RA-SAGE 3 layers']['rho']), ('SAGE + rank λ=0.25', abl['SAGE + rank (lambda=0.25)']['rho']), ('SAGE + rank λ=1', abl['SAGE + rank (lambda=1)']['rho']),
        ('GCN', results[P]['GCN']['rho']), ('GCN + rank loss', abl['GCN + rank loss']['rho'])]
rows[1] = ('RA-SAGE, 1 layer', abl['RA-SAGE 1 layer']['rho'])
ax = axs[0]
for i, (nm, (m_, s_)) in enumerate(rows[::-1]):
    c = RED if 'λ=0.5' in nm else MID
    ax.errorbar(m_, i, xerr=s_, fmt='o', color=c, ms=6.5, capsize=3, lw=1.2); ax.plot([0.96, m_], [i, i], color=LGRAY, lw=0.9, zorder=0)
ax.set_yticks(range(len(rows))); ax.set_yticklabels([r[0] for r in rows[::-1]], fontsize=8.5); ax.set_xlim(0.96, 1.0); ax.set_xlabel('Spearman ρ (p = 0.02)'); ax.set_title('(a) Ablations', fontsize=9.5)
ax = axs[1]; fr = sorted(labeff); m_ = np.array([labeff[f][0] for f in fr]); s_ = np.array([labeff[f][1] for f in fr])
ax.fill_between([100*f for f in fr], m_-s_, m_+s_, color=LIGHT, alpha=0.9, linewidth=0); ax.plot([100*f for f in fr], m_, color=RED, marker='o', ms=5, lw=2)
ax.set_xscale('log'); ax.minorticks_off(); ax.set_xticks([2, 5, 10, 20, 40, 70]); ax.set_xticklabels(['2', '5', '10', '20', '40', '70']); ax.set_xlabel('% of users with simulated labels'); ax.set_ylabel('Spearman ρ on held-out users'); ax.set_title('(b) Label efficiency', fontsize=9.5)
fig.tight_layout(); fig.savefig(f'{FIGDIR}/fig_ablation.png'); plt.close(fig)
print('figures done', gat_rho)
