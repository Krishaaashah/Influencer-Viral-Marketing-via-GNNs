from paths import DATA, RESULTS, FIGS, REPORT, FIGDIR
import pickle, json, re, numpy as np
from docx import Document
from docx.shared import Pt, Inches, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.section import WD_ORIENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

RED = RGBColor(0xC8, 0x10, 0x2E); DARK = RGBColor(0x7A, 0x00, 0x19); INK = RGBColor(0x22, 0x22, 0x22); GRAYC = RGBColor(0x55, 0x55, 0x55)
FONT = 'Times New Roman'
results, oof, LAB = pickle.load(open(RESULTS / 'main_stage1.pkl', 'rb')); seeds = pickle.load(open(RESULTS / 'seeds.pkl', 'rb'))
abl = pickle.load(open(RESULTS / 'ablations.pkl', 'rb')); le = pickle.load(open(RESULTS / 'label_eff.pkl', 'rb')); cr = pickle.load(open(RESULTS / 'cross_p.pkl', 'rb'))
gat = json.load(open(RESULTS / 'gat_results.json')); S = json.load(open(RESULTS / 'stats.json')); N = S['n']
gat_s = {'rho': (np.mean([r['rho'] for r in gat]), np.std([r['rho'] for r in gat])), 'prec': (np.mean([r['prec'] for r in gat]), np.std([r['prec'] for r in gat])), 'r2': (np.mean([r['r2'] for r in gat]), np.std([r['r2'] for r in gat]))}
P = 0.02; R = results[P]; SP = seeds[P]['spread']

doc = Document()
sec = doc.sections[0]; sec.page_width = Cm(21.0); sec.page_height = Cm(29.7)
for a in ('left_margin', 'right_margin', 'top_margin', 'bottom_margin'): setattr(sec, a, Inches(1))

def set_font(style_or_run, size=None, bold=None, italic=None, color=None):
    f = style_or_run.font; f.name = FONT
    if size: f.size = Pt(size)
    if bold is not None: f.bold = bold
    if italic is not None: f.italic = italic
    if color is not None: f.color.rgb = color
    rpr = style_or_run.element.get_or_add_rPr() if hasattr(style_or_run.element, 'get_or_add_rPr') else style_or_run.element.rPr
    rf = rpr.find(qn('w:rFonts'))
    if rf is None: rf = OxmlElement('w:rFonts'); rpr.insert(0, rf)
    for a in ('w:ascii', 'w:hAnsi', 'w:eastAsia', 'w:cs'): rf.set(qn(a), FONT)
    for a in ('w:asciiTheme', 'w:hAnsiTheme', 'w:eastAsiaTheme', 'w:cstheme'):
        if rf.get(qn(a)) is not None: del rf.attrib[qn(a)]

st = doc.styles
set_font(st['Normal'], 12, color=INK); st['Normal'].paragraph_format.space_after = Pt(6); st['Normal'].paragraph_format.line_spacing = 1.15
for name, size, col, before, after in [('Heading 1', 16, RED, 18, 6), ('Heading 2', 14, DARK, 12, 4), ('Heading 3', 12, DARK, 8, 3)]:
    s = st[name]; set_font(s, size, bold=True, italic=False, color=col); s.paragraph_format.space_before = Pt(before); s.paragraph_format.space_after = Pt(after); s.paragraph_format.keep_with_next = True
for name in ('List Bullet', 'List Number'): set_font(st[name], 12, color=INK); st[name].paragraph_format.space_after = Pt(3)

def add_runs(par, text, size=None, color=None, italic=None):
    for tok in re.split(r'(\*\*.+?\*\*|//.+?//)', text):
        if not tok: continue
        if tok.startswith('**'): r = par.add_run(tok[2:-2]); set_font(r, size, bold=True, color=color, italic=italic)
        elif tok.startswith('//'): r = par.add_run(tok[2:-2]); set_font(r, size, italic=True, color=color)
        else: r = par.add_run(tok); set_font(r, size, color=color, italic=italic)
    return par

def para(text, align='justify', size=None, after=None, color=None, italic=None, keep=False):
    p = doc.add_paragraph(); add_runs(p, text, size, color, italic)
    p.alignment = {'justify': WD_ALIGN_PARAGRAPH.JUSTIFY, 'center': WD_ALIGN_PARAGRAPH.CENTER, 'left': WD_ALIGN_PARAGRAPH.LEFT}[align]
    if after is not None: p.paragraph_format.space_after = Pt(after)
    if keep: p.paragraph_format.keep_with_next = True
    return p

def bullets(items, style='List Bullet'):
    for t in items:
        p = doc.add_paragraph(style=style); add_runs(p, t); p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

def h1(t): return doc.add_heading(t, 1)
def h2(t): return doc.add_heading(t, 2)
def h3(t): return doc.add_heading(t, 3)

def rule(p, color='C8102E', sz=12):
    pPr = p._p.get_or_add_pPr(); b = OxmlElement('w:pBdr'); e = OxmlElement('w:bottom')
    for k, v in (('w:val', 'single'), ('w:sz', str(sz)), ('w:space', '1'), ('w:color', color)): e.set(qn(k), v)
    b.append(e); pPr.append(b)

def shade(cell, hexcolor):
    tcPr = cell._tc.get_or_add_tcPr(); sh = OxmlElement('w:shd'); sh.set(qn('w:val'), 'clear'); sh.set(qn('w:color'), 'auto'); sh.set(qn('w:fill'), hexcolor); tcPr.append(sh)

def cell_borders(cell, color='D9A0A8', sz=4):
    tcPr = cell._tc.get_or_add_tcPr(); b = OxmlElement('w:tcBorders')
    for side in ('top', 'left', 'bottom', 'right'):
        e = OxmlElement(f'w:{side}'); e.set(qn('w:val'), 'single'); e.set(qn('w:sz'), str(sz)); e.set(qn('w:color'), color); b.append(e)
    tcPr.append(b)

def cell_margins(table, top=50, bottom=50, left=90, right=90):
    tblPr = table._tbl.tblPr; m = OxmlElement('w:tblCellMar')
    for side, v in (('top', top), ('left', left), ('bottom', bottom), ('right', right)):
        e = OxmlElement(f'w:{side}'); e.set(qn('w:w'), str(v)); e.set(qn('w:type'), 'dxa'); m.append(e)
    tblPr.append(m)

CAP = {'fig': 0, 'tab': 0}
def caption(kind, text):
    CAP[kind] += 1; label = 'Figure' if kind == 'fig' else 'Table'
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_after = Pt(8 if kind == 'fig' else 3); p.paragraph_format.space_before = Pt(2 if kind == 'fig' else 8)
    r = p.add_run(f'{label} {CAP[kind]}: '); set_font(r, 11, bold=True, color=RED); add_runs(p, text, 11, color=INK, italic=True)
    if kind == 'tab': p.paragraph_format.keep_with_next = True
    return p

def figure(path, width, text):
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_after = Pt(2); p.paragraph_format.keep_with_next = True
    p.add_run().add_picture(path, width=Inches(width)); caption('fig', text)

def table(headers, rows, widths, caption_text, align=None, bold_rows=(), size=11, hl_rows=()):
    caption('tab', caption_text)
    t = doc.add_table(rows=1 + len(rows), cols=len(headers)); t.alignment = WD_TABLE_ALIGNMENT.CENTER; t.autofit = False; cell_margins(t)
    for j, h in enumerate(headers):
        c = t.rows[0].cells[j]; c.width = Inches(widths[j]); shade(c, 'C8102E'); cell_borders(c, 'C8102E'); c.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER if (align and align[j] == 'c') else WD_ALIGN_PARAGRAPH.LEFT; p.paragraph_format.space_after = Pt(0); p.paragraph_format.line_spacing = 1.0
        r = p.add_run(h); set_font(r, size, bold=True, color=RGBColor(255, 255, 255))
    for i, row in enumerate(rows):
        for j, v in enumerate(row):
            c = t.rows[i+1].cells[j]; c.width = Inches(widths[j]); cell_borders(c); c.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            if i in hl_rows: shade(c, 'F6D0D4')
            elif i % 2 == 1: shade(c, 'FCEDEE')
            p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER if (align and align[j] == 'c') else WD_ALIGN_PARAGRAPH.LEFT
            p.paragraph_format.space_after = Pt(0); p.paragraph_format.line_spacing = 1.0
            add_runs(p, ('**' + str(v) + '**') if (i in bold_rows and not str(v).startswith('**')) else str(v), size, color=INK)
    # repeat header row
    trPr = t.rows[0]._tr.get_or_add_trPr(); th = OxmlElement('w:tblHeader'); th.set(qn('w:val'), 'true'); trPr.append(th)
    for row in t.rows:
        trPr = row._tr.get_or_add_trPr(); cs = OxmlElement('w:cantSplit'); cs.set(qn('w:val'), 'true'); trPr.append(cs)
    for j, w in enumerate(widths): t.columns[j].width = Inches(w)
    for row in t.rows[:-1]:
        for c in row.cells:
            for pp in c.paragraphs: pp.paragraph_format.keep_with_next = True
    sp = doc.add_paragraph(); sp.paragraph_format.space_after = Pt(4); sp.paragraph_format.line_spacing = 0.6
    return t

def eq(text):
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_after = Pt(6)
    r = p.add_run(text); set_font(r, 12, italic=True, color=INK); return p

def pagebreak(): doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)

def fmt(m, s=None, d=3): return f'{m:.{d}f}' if s is None else f'{m:.{d}f} ± {s:.{d}f}'

# ============ header / footer ============
hp = sec.header.paragraphs[0]; hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
r = hp.add_run('Influencer Identification and Viral Marketing using Graph Neural Networks'); set_font(r, 10, italic=True, color=GRAYC); rule(hp, 'C8102E', 6)
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = fp.add_run('Page '); set_font(r, 10, color=GRAYC)
for kind, txt in (('begin', None), (None, 'PAGE'), ('end', None)):
    rr = fp.add_run(); set_font(rr, 10, color=GRAYC)
    if kind: fc = OxmlElement('w:fldChar'); fc.set(qn('w:fldCharType'), kind); rr._r.append(fc)
    else: it = OxmlElement('w:instrText'); it.set(qn('xml:space'), 'preserve'); it.text = txt; rr._r.append(it)
sec.different_first_page_header_footer = True

# ============ cover page ============
band = doc.add_table(rows=1, cols=1); band.alignment = WD_TABLE_ALIGNMENT.CENTER; c = band.rows[0].cells[0]; shade(c, 'C8102E'); c.width = Inches(6.27)
cell_margins(band, 200, 200, 200, 200)
p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER; r = p.add_run('SYMBIOSIS INSTITUTE OF TECHNOLOGY, PUNE'); set_font(r, 16, bold=True, color=RGBColor(255, 255, 255)); p.paragraph_format.space_after = Pt(2)
p = c.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER; r = p.add_run('Constituent of Symbiosis International (Deemed University), Pune'); set_font(r, 12, color=RGBColor(255, 255, 255)); p.paragraph_format.space_after = Pt(0)
for _ in range(3): doc.add_paragraph()
p = para('CA3: Graph-Based Case Study', 'center', 14, color=DARK); p.runs[0].bold = True
p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_before = Pt(18); p.paragraph_format.space_after = Pt(6)
r = p.add_run('Influencer Identification and Viral Marketing on Social Networks using Graph Neural Networks'); set_font(r, 22, bold=True, color=RED)
p = para('A learned influence surrogate and diversity-aware seed selection on a real Facebook friendship network', 'center', 13, color=GRAYC, italic=True); rule(p, 'C8102E', 12); p.paragraph_format.space_after = Pt(30)
for _ in range(2): doc.add_paragraph()
p = para('Submitted by', 'center', 12, color=DARK); p.runs[0].bold = True
tm = doc.add_table(rows=4, cols=2); tm.alignment = WD_TABLE_ALIGNMENT.CENTER; tm.autofit = False; cell_margins(tm, 70, 70, 120, 120)
for j, h in enumerate(['Team member', 'PRN']):
    c = tm.rows[0].cells[j]; c.width = Inches(3.0 if j == 0 else 2.2); shade(c, 'C8102E'); cell_borders(c, 'C8102E'); pp = c.paragraphs[0]; pp.alignment = WD_ALIGN_PARAGRAPH.CENTER; pp.paragraph_format.space_after = Pt(0)
    rr = pp.add_run(h); set_font(rr, 12, bold=True, color=RGBColor(255, 255, 255))
for i, (nm, prn) in enumerate([('Krisha Shah', '24070126512'), ('Janhavi Doijad', '23070126153'), ('Sahil Awatrami', '23070126112')]):
    for j, v in enumerate((nm, prn)):
        c = tm.rows[i+1].cells[j]; c.width = Inches(3.0 if j == 0 else 2.2); cell_borders(c)
        if i % 2 == 1: shade(c, 'FCEDEE')
        pp = c.paragraphs[0]; pp.alignment = WD_ALIGN_PARAGRAPH.CENTER; pp.paragraph_format.space_after = Pt(0); rr = pp.add_run(v); set_font(rr, 12, color=INK)
for _ in range(3): doc.add_paragraph()
para('October 2026', 'center', 12, color=GRAYC)
pagebreak()

# ============ abstract + contents ============
h1('Abstract')
ra, gd = R['RA-SAGE (ours)'], SP[20]
para(f'Brands increasingly spend marketing budgets on a handful of well-connected users in the hope that their posts will cascade through a social network. Choosing those users is the influence-maximization problem, which is computationally hard and normally relies on repeated Monte-Carlo simulation. This case study asks whether a Graph Neural Network (GNN) can learn to predict how far a message started by a given user will spread, and whether those predictions can be turned into better campaigns. We model the SNAP ego-Facebook network ({N:,} users, {S["m"]:,} friendships) as a graph, simulate cascades with an independent-cascade (SIR) process at three transmission probabilities, and train GCN, GraphSAGE and GAT models using only three cheap structural features per user.')
para(f'On held-out users, a rank-aware GraphSAGE variant (RA-SAGE) reaches a Spearman correlation of {ra["rho"][0]:.3f} with true influence, compared with {R["Degree"]["rho"][0]:.3f} for degree and {R["PageRank"]["rho"][0]:.3f} for PageRank, and it needs simulated labels for only about 20% of users to do so. Our key finding is that accurate individual scores are not enough: choosing the 20 highest-scoring users reaches only {SP[20]["RA-SAGE top-k"]:,.0f} users ({100*SP[20]["RA-SAGE top-k"]/N:.0f}%), because they all sit in one dense community. Adding a simple diversity discount (GNN-GDS) lifts reach to {gd["GNN-GDS (ours)"]:,.0f} users, a {100*(gd["GNN-GDS (ours)"]/gd["RA-SAGE top-k"]-1):.0f}% improvement and {100*gd["GNN-GDS (ours)"]/gd["Greedy (reference)"]:.0f}% of a simulation-based greedy reference. We also report where the approach falls short: PageRank and the greedy reference remain stronger seed selectors, and the practical benefit of a surrogate depends on the cost of the underlying simulator.')
para('The case study is organised so that each section corresponds to one criterion of the CA3 rubric, as summarised below.', after=4)
table(['Rubric criterion', 'CO', 'Marks', 'Where addressed'], [['Problem understanding and graph formulation', 'CO1', '2', 'Section 1'], ['Selection of graph representation / embedding technique', 'CO2', '1', 'Section 2'], ['Data preparation and implementation', 'CO3', '2', 'Section 3'], ['Application of GNN architecture', 'CO4', '2', 'Section 4'], ['Innovation and creativity', 'CO5', '3', 'Section 5'], ['Results interpretation and real-world impact', 'CO5', '3', 'Sections 6 and 7']], [3.0, 0.6, 0.7, 1.6], 'Mapping of the case study to the CA3 evaluation rubric.', align=['l', 'c', 'c', 'l'])
pagebreak()

# ============ 1 ============
h1('1  Problem Understanding and Graph Formulation')
h2('1.1  Business context')
para('Word-of-mouth is one of the cheapest and most credible forms of marketing. When a user shares, recommends or adopts a product, some of their friends are exposed and a fraction of them do the same, so a single well-placed seed can trigger a cascade that reaches thousands of people. Brands therefore pay influencers and run referral programmes with a fixed budget, and the central question is which k users to target so that the expected number of people reached is as large as possible.')
para('Two practical difficulties make this hard. First, a user\'s influence is not their follower count: it depends on who their friends are, how those friends are connected to each other, and whether the audience overlaps with that of other seeds. Second, estimating influence directly requires running a large number of cascade simulations for every candidate, which is expensive on big networks and for rich diffusion models. A model that predicts influence directly from the network structure would remove this bottleneck.')
h2('1.2  Problem statement')
para('//Given a social network and a diffusion model, (i) predict the expected reach of every user as a seed, using simulated outcomes for only a sample of users as training data, and (ii) use these predictions to select a set of k seed users that maximises the expected campaign reach.//')
para('This is a natural graph learning problem: the label of a node (its influence) is determined by the structure of its multi-hop neighbourhood, which is exactly what message-passing GNNs are designed to aggregate. We formulate the work as three research questions.')
bullets(['**RQ1.** Can a GNN trained on simulated labels for a minority of users accurately rank all other users by influence, and does it beat degree, PageRank and hand-crafted features?', '**RQ2.** How many labelled users are needed, and does a model trained at one transmission probability transfer to others?', '**RQ3.** Are the learned scores sufficient for choosing a //set// of seeds, or is an additional mechanism needed?'], 'List Number')
h2('1.3  Graph formulation')
para('The social network is modelled as an undirected, unweighted graph G = (V, E) with adjacency matrix A. Table 2 maps every marketing concept to a graph element.')
table(['Marketing concept', 'Graph element', 'Role in the model'], [['User / customer', 'Node v ∈ V', 'Prediction target (influence) and unit of selection'], ['Friendship / follow tie', 'Undirected edge (u, v) ∈ E', 'Channel along which a message can spread'], ['User profile signals', 'Node features x_v', 'Log-degree, clustering coefficient, core number'], ['Probability a friend re-shares', 'Edge transmission probability p', 'Parameter of the diffusion process'], ['Seed (influencer) set', 'Subset S ⊆ V, |S| = k', 'Decision variable of the campaign'], ['Campaign reach', 'σ(S) = E[ |R(S)| ]', 'Objective to maximise']], [1.9, 1.9, 2.1], 'Mapping of marketing concepts to graph elements.')
h3('Diffusion model')
para('We use the independent-cascade model in its undirected, single-trial form: every friendship transmits the message independently with probability p. A random realisation ("snapshot") keeps each edge with probability p; the set of users reached from a seed set S is the union of the connected components of the snapshot that contain a seed. This is equivalent to an SIR epidemic with transmissibility p and to bond percolation on the network [9]. The expected reach of a seed set and the influence of a single user v are')
eq('σ(S) = E[ |R(S)| ] ,    y_v = σ({v}) = E[ size of the component containing v ] .')
para(f'Maximising σ(S) under |S| = k is NP-hard, but σ is monotone and submodular, so the greedy algorithm achieves at least (1 − 1/e) of the optimum [1]. Greedy is, however, simulation-hungry, which motivates a learned surrogate. The percolation threshold of this network is p_c = ⟨k⟩ / (⟨k²⟩ − ⟨k⟩) ≈ {S["Tc"]:.4f}, so we study p = 0.01 (at the threshold), p = 0.02 (about twice the threshold, our main setting) and p = 0.03, where very large cascades become common.')
h3('Learning task')
para('Node-level regression: learn f_θ(G, X) → ŷ with ŷ_v ≈ log(1 + y_v). The logarithm compresses the heavy-tailed distribution of influence. Because the downstream decision depends on the //ordering// of users rather than on exact values, we evaluate with rank-based metrics and add a ranking term to the loss (Section 5).')

# ============ 2 ============
h1('2  Dataset and Graph Representation')
h2('2.1  Dataset')
para(f'We use the SNAP ego-Facebook network [7, 11], an anonymised union of ten Facebook ego networks: nodes are users and an edge means that two users are friends. The graph is connected with {N:,} users and {S["m"]:,} friendships. Table 3 summarises its structure, and Figure 1 shows why it is a demanding test: degrees follow a heavy-tailed distribution, so a few hub users have hundreds of friends, while the typical user has about {S["med_deg"]:.0f}. Reach grows steeply with degree but with a very wide spread, which means degree alone cannot rank users well.')
table(['Property', 'Value'], [['Users (nodes)', f'{N:,}'], ['Friendships (edges)', f'{S["m"]:,}'], ['Density', f'{S["density"]:.4f}'], ['Average / median / maximum degree', f'{S["avg_deg"]:.1f} / {S["med_deg"]:.0f} / {S["max_deg"]:,}'], ['Average clustering coefficient', f'{S["clust"]:.3f}'], ['Diameter / average shortest path', f'{S["diam"]} / {S["avg_path"]:.2f}'], ['Communities (Louvain) / modularity', f'{S["ncomm"]} / {S["modularity"]:.3f}'], ['Maximum k-core number', f'{S["core_max"]}'], ['Percolation threshold p_c', f'{S["Tc"]:.4f}']], [3.4, 2.2], 'Structural statistics of the ego-Facebook network (computed in this study).', align=['l', 'c'])
figure(f'{FIGDIR}/fig_profile.png', 6.0, 'Degree distribution (left) and relationship between degree and simulated expected reach at p = 0.02 (right). Many users with similar degree have very different reach.')
para(f'The high clustering ({S["clust"]:.2f}) and strong community structure (modularity {S["modularity"]:.2f}) matter for marketing: friends of a seed tend to be friends of each other, so two seeds in the same community largely reach the same audience. This redundancy is the origin of the main finding in Section 6.')
h2('2.2  Choice of graph representation')
para('We compared four ways of representing the network for learning (Table 4). We chose a sparse edge-list representation with explicit node features and message-passing GNN layers.')
table(['Representation', 'Advantages', 'Drawbacks for this task', 'Decision'], [['Dense adjacency matrix', 'Simple to implement', f'{N:,}² entries; wasteful for a graph with density {S["density"]:.3f}', 'Not used'], ['Sparse edge list / sparse adjacency', 'Memory-efficient; supports message passing on any graph size', 'Needs sparse kernels', '**Chosen**'], ['Pre-computed node embeddings (node2vec, DeepWalk)', 'Capture proximity; reusable', 'Transductive; embeddings must be recomputed for new nodes; not trained on the influence objective', 'Not used'], ['Hand-crafted structural features only (no graph layers)', 'Fast, interpretable', 'Requires manual feature design; kept as a baseline (GBM)', 'Baseline']], [1.5, 1.5, 2.0, 0.9], 'Candidate graph representations and the choice made.')
para('The decisive arguments are: (i) message passing learns neighbourhood aggregates automatically, whereas the baselines need hand-built multi-hop features; (ii) the GNN is trained end-to-end on the influence objective rather than on a proximity objective unrelated to cascades; and (iii) GraphSAGE-style aggregation is inductive, so the trained model can score users who join the network later without retraining from scratch.')

# ============ 3 ============
h1('3  Data Preparation and Implementation')
figure(f'{FIGDIR}/fig_pipeline.png', 6.1, 'End-to-end pipeline: simulate cascades, learn an influence surrogate from a sample of users, predict for everyone, and select campaign seeds.')
h2('3.1  Label generation')
para('For each transmission probability p ∈ {0.01, 0.02, 0.03} we generated two independent sets of snapshots. A set of 300 snapshots provides the (noisy) training labels y_v = mean component size of v. A separate set of 2,000 snapshots provides low-noise ground truth used only for evaluation, so that models are never scored against the noise they were trained on. Because each snapshot is a connected-components computation, all {0} users are labelled simultaneously from the same snapshots.'.replace('{0}', f'{N:,}'))
h2('3.2  Node features and preprocessing')
table(['Feature', 'Definition', 'Preprocessing'], [['Log-degree', 'log(1 + number of friends)', 'Standardised (zero mean, unit variance)'], ['Clustering coefficient', 'Fraction of a user\'s friend pairs who are also friends', 'Standardised'], ['Core number', 'Largest k such that the user belongs to the k-core, divided by the maximum core number', 'Standardised']], [1.5, 3.0, 1.5], 'Input features (deliberately local and cheap to compute).', align=['l', 'l', 'l'])
para('Only these three features are given to the GNNs. Anything that requires looking beyond a user\'s immediate neighbourhood (for example friends\' degrees or two-hop reach) must be learned through message passing. The regression target is log(1 + y_v), standardised using the training-fold mean and standard deviation.')
h2('3.3  Evaluation protocol')
bullets(['**Five-fold cross-fitting.** Users are split into five folds. For each fold, a model is trained on the other four (10% of those held out for early stopping) and used to predict the held-out fold, so every user receives an //out-of-fold// prediction from a model that never saw their label. These predictions are what we use later for seed selection.', '**Metrics** on held-out users, against the 2,000-snapshot ground truth: Spearman rank correlation ρ, top-5% precision (fraction of the true top 5% recovered), and R² on the log scale. Results are mean ± standard deviation over folds.', '**Fresh evaluation snapshots.** Campaign reach of every seed set is measured on 3,000 snapshots that were not used for training, tuning or greedy selection.'])
h2('3.4  Implementation')
table(['Item', 'Setting'], [['Software', 'Python 3.13, PyTorch 2.14 (CPU), NetworkX, SciPy, scikit-learn; message-passing layers written directly with sparse operations'], ['Optimiser', 'Adam, learning rate 0.01, weight decay 5 × 10⁻⁴'], ['Capacity', '64 hidden units, 2 message-passing layers, MLP head 64 → 64 → 1, dropout 0.1; GAT uses 4 heads'], ['Training', 'Up to 250 epochs (150 for GAT), early stopping on validation Spearman (patience 40; 30 for GAT)'], ['Ranking term (RA-SAGE)', 'λ = 0.5, 20,000 random user pairs per step, pairwise logistic loss'], ['Hardware / time', f'2 CPU cores; about {R["GraphSAGE"]["train_s"]:.0f} s per GraphSAGE fold and {np.mean([r["secs"] for r in gat]):.0f} s per GAT fold']], [1.7, 4.3], 'Implementation and training configuration.', align=['l', 'l'])
para('The ego-Facebook edge list was obtained from a public mirror of the SNAP file; it matches the published statistics (4,039 nodes, 88,234 edges). All simulations and models in this report were run for this study, and random seeds are fixed for reproducibility.')

# ============ 4 ============
h1('4  GNN Architecture')
h2('4.1  Models compared')
para('A GNN layer updates each user\'s representation by aggregating messages from friends. We compare three standard layers that differ in how neighbours are weighted, plus two non-graph reference models.')
table(['Model', 'Update rule (simplified)', 'Characteristic'], [['GCN [4]', 'h_v′ = ReLU( Σ_u (1 / √(d_u d_v)) · W h_u )', 'Symmetric degree normalisation; self-loops'], ['GraphSAGE [5]', 'h_v′ = ReLU( W₁ h_v + W₂ · mean_{u ∈ N(v)} h_u )', 'Separate self and neighbour weights; inductive'], ['GAT [6]', 'h_v′ = ELU( Σ_u α_vu W h_u ),  α = softmax(LeakyReLU(aᵀ[W h_v ‖ W h_u]))', 'Learned attention over friends; 4 heads'], ['MLP', 'h_v′ = ReLU( W h_v )', 'No graph information (control)'], ['GBM', 'Gradient boosting on seven hand-crafted features', 'Strong classical baseline (see Section 6)']], [1.2, 3.1, 1.7], 'Models compared in this study.', align=['l', 'l', 'l'])
figure(f'{FIGDIR}/fig_architecture.png', 6.0, 'Architecture of the proposed RA-SAGE model: two GraphSAGE layers aggregate friend and friend-of-friend information, an MLP head outputs the influence score, and training combines a regression loss with a pairwise ranking loss.')
h2('4.2  Why GraphSAGE is the backbone of the proposed model')
para('Influence in a cascade depends on how many neighbours a user has and on how //their// neighbours are connected. GraphSAGE keeps the user\'s own signal separate from the averaged neighbour signal, so the model can learn that a user with moderate degree but well-connected friends is influential. GCN\'s symmetric normalisation shrinks the contribution of hubs, which is the opposite of what a spreading process needs, and GAT\'s attention adds parameters and was roughly seven times slower per fold here without improving accuracy (Section 6). Two layers give each user a two-hop receptive field; Section 6.2 shows this is the smallest depth that comes close to the best accuracy.')
h2('4.3  Training objective')
para('Let ŷ_v be the model output and y_v the standardised target. For the proposed RA-SAGE the loss combines regression with a pairwise ranking term in the style of RankNet [12]:')
eq('L = (1/|T|) Σ_{v ∈ T} (ŷ_v − y_v)²  +  λ · E_{(u,v)} [ log(1 + exp( −sign(y_u − y_v) · (ŷ_u − ŷ_v) )) ] .')
para('The first term makes scores well calibrated; the second directly rewards ordering users correctly, which is what seed selection needs. Pairs whose true values differ by less than 0.05 standard deviations are skipped so that label noise is not treated as signal.')

# ============ 5 ============
h1('5  Innovation and Creativity')
para('The study goes beyond applying an off-the-shelf GNN in three ways.')
h2('5.1  Influence surrogate learned from a sample of users')
para('Instead of simulating cascades for every candidate, simulations are run once to label a sample of users and the GNN generalises to the rest. Because GraphSAGE is inductive, the same trained model can in principle score users in a new or growing network. Section 6.2 quantifies how small the labelled sample can be.')
h2('5.2  Rank-aware loss')
para('Seed selection depends on ordering, not on squared error. Adding the pairwise ranking term (Section 4.3) gives the model a training signal aligned with the downstream decision. We report honestly in Section 6.2 that the measured gain over plain GraphSAGE is small but consistent.')
h2('5.3  Out-of-fold scoring exposes the "top-k trap"')
para('Because every user is scored by a model that never saw their label, we can test the realistic deployment scenario. This revealed a failure that headline accuracy hides: although the ranking of individual users is almost perfect, simply taking the k highest scores selects users from the same dense community, whose audiences overlap almost completely.')
h2('5.4  GNN-GDS: diversity-aware seed selection')
para('To address the trap we propose GNN-GDS (GNN-guided Diversity-aware Selection), a greedy procedure that starts from the learned scores s_v = exp(ŷ_v) − 1 and discounts users near seeds that have already been chosen:')
eq('score′(v) = s_v · f₁^{a₁(v)} · f₂^{a₂(v)} ,')
para('where a₁(v) is the number of chosen seeds that are direct friends of v, a₂(v) the number at distance exactly two, and f₁, f₂ ∈ (0, 1] are discount factors. At each step the user with the highest discounted score becomes the next seed. The method resembles DegreeDiscount [3] but replaces degree with a learned influence score and adds a second-hop discount. f₁ and f₂ are tuned for each budget k on a separate set of 500 snapshots that is not used for evaluation. Selecting 50 seeds takes about 0.03 s once the scores exist.')

# ============ 6 ============
h1('6  Results and Interpretation')
h2('6.1  How well can influence be predicted? (RQ1)')
rows = []
order = ['Degree', 'PageRank', 'k-core', '2-hop reach', 'GBM (hand-crafted)', 'MLP', 'GCN', 'GAT', 'GraphSAGE', 'RA-SAGE (ours)']
for m in order:
    v = gat_s if m == 'GAT' else R[m]
    rows.append([m, fmt(v['rho'][0], v['rho'][1]), fmt(v['prec'][0], v['prec'][1], 2), '–' if (m in ('Degree', 'PageRank', 'k-core', '2-hop reach')) else fmt(v['r2'][0], None)])
table(['Method', 'Spearman ρ', 'Top-5% precision', 'R² (log scale)'], rows, [2.0, 1.5, 1.4, 1.1], 'Prediction of single-user influence at p = 0.02 on held-out users (mean ± std over 5 folds). Heuristic rows are used as direct rankings.', align=['l', 'c', 'c', 'c'], bold_rows=(9,), hl_rows=(9,))
figure(f'{FIGDIR}/fig_models.png', 5.6, 'Rank correlation between predicted and true influence for all methods (p = 0.02). Error bars show one standard deviation over folds.')
para(f'**Interpretation.** Every GNN with message passing ranks users far better than degree (ρ = {R["Degree"]["rho"][0]:.2f}) or any single structural heuristic. The MLP, which sees exactly the same three features but no neighbours, reaches only {R["MLP"]["rho"][0]:.2f}, so the improvement comes from the graph and not from the features themselves. PageRank and two-hop reach rank poorly as //individual// predictors ({R["PageRank"]["rho"][0]:.2f} and {R["2-hop reach"]["rho"][0]:.2f}) because the most influential single users sit inside a dense community rather than at the global centre of the network. GraphSAGE and RA-SAGE ({R["GraphSAGE"]["rho"][0]:.3f} and {R["RA-SAGE (ours)"]["rho"][0]:.3f}) are the best, with GAT ({gat_s["rho"][0]:.3f}) statistically close and GCN lower ({R["GCN"]["rho"][0]:.3f}), consistent with the hub-shrinking effect of its normalisation.')
para(f'**An honest comparison with gradient boosting.** A gradient-boosting model fed seven hand-crafted features (including PageRank, neighbour degree and two-hop reach) achieves ρ = {R["GBM (hand-crafted)"]["rho"][0]:.3f}, within about 0.002 of the best GNN, and trains in under a second. The GNN advantage is therefore not raw accuracy on this graph; it is that the GNN reaches this level from three raw local features without manual feature engineering, and that it extends naturally to richer inputs such as node attributes or multiple edge types, where hand-crafting becomes impractical.')
figure(f'{FIGDIR}/fig_scatter.png', 3.9, 'Predicted versus simulated expected reach for held-out users (RA-SAGE, p = 0.02, both axes logarithmic). The dashed line is perfect prediction.')
para('Predictions track the truth closely across three orders of magnitude. The largest errors occur at the very top of the scale, where the model overestimates users inside the densest community (predicting roughly 650 to 700 users for individuals whose true reach is about 520 to 530); this has consequences for seed selection discussed in Section 6.3.')
h3('Other transmission probabilities')
rows = []
for m in ['Degree', 'GBM (hand-crafted)', 'MLP', 'GCN', 'GraphSAGE', 'RA-SAGE (ours)']:
    rows.append([m] + [fmt(results[p][m]['rho'][0], results[p][m]['rho'][1]) for p in (0.01, 0.02, 0.03)])
table(['Method', 'p = 0.01', 'p = 0.02', 'p = 0.03'], rows, [2.0, 1.35, 1.35, 1.35], 'Spearman ρ on held-out users for three transmission probabilities (mean ± std over folds). GAT was run at p = 0.02 only because of its cost.', align=['l', 'c', 'c', 'c'], bold_rows=(5,), hl_rows=(5,))
para('The ordering of methods is stable across all three regimes, including at the percolation threshold (p = 0.01) where cascades are small and highly variable.')

h2('6.2  Ablations, label efficiency and transfer (RQ2)')
figure(f'{FIGDIR}/fig_ablation.png', 6.2, '(a) Ablation of depth, ranking weight λ and layer type (p = 0.02). (b) Accuracy as a function of the share of users with simulated labels.')
a1 = abl['RA-SAGE 1 layer']['rho'][0]; a3 = abl['RA-SAGE 3 layers']['rho'][0]
para(f'**Depth matters.** A single layer gives ρ = {a1:.3f}, two layers {ra["rho"][0]:.3f} and three layers {a3:.3f}: aggregating over a wider neighbourhood keeps helping because cascades travel several hops. The best configuration overall is therefore the three-layer variant, although we keep two layers as the main model to match the baselines. **The ranking term has a small effect.** Adding it changes ρ from {R["GraphSAGE"]["rho"][0]:.4f} to {ra["rho"][0]:.4f} at p = 0.02, from {results[0.01]["GraphSAGE"]["rho"][0]:.4f} to {results[0.01]["RA-SAGE (ours)"]["rho"][0]:.4f} at p = 0.01 and from {results[0.03]["GraphSAGE"]["rho"][0]:.4f} to {results[0.03]["RA-SAGE (ours)"]["rho"][0]:.4f} at p = 0.03. The direction is consistent, and the fold-to-fold spread shrinks, but at p = 0.02 and 0.03 the gain is within about one standard deviation, so we do not claim it as significant there. It also did not help GCN (ρ = {abl["GCN + rank loss"]["rho"][0]:.3f} against {R["GCN"]["rho"][0]:.3f}, a slight gain with lower top-5% precision).')
fe = {k: v for k, v in le.items()}
para(f'**Few labels are enough.** With only 5% of users labelled the model reaches ρ = {fe[0.05][0]:.3f}, with 10% {fe[0.1][0]:.3f}, and with 20% {fe[0.2][0]:.3f}; beyond 20% the curve is flat ({fe[0.7][0]:.3f} at 70%). In a setting where each label costs many simulations, this means the expensive part can be limited to a small fraction of the network.')
pc = lambda a, b: cr[(a, b)]
figure(f'{FIGDIR}/fig_crossp.png', 3.4, 'Transfer across transmission probabilities: Spearman ρ between predictions of a model trained at one p (rows) and true influence at another p (columns), pooled over out-of-fold predictions.')
para(f'**Transfer is good but not free.** A model trained at one probability still ranks users well at another (ρ between {min(v for (a, b), v in cr.items() if a != b):.2f} and {max(v for (a, b), v in cr.items() if a != b):.2f}), but accuracy drops with the distance between the two probabilities, with the largest drops between the two most distant values (0.01 and 0.03). Practically, if the true share probability of a campaign is uncertain, the model should be retrained or fine-tuned on labels from a simulation close to the expected value.')

h2('6.3  From scores to campaigns (RQ3)')
meths = ['Random', 'Degree', 'PageRank', 'Degree-Discount', 'RA-SAGE top-k', 'GNN-GDS (ours)', 'Greedy (reference)']
disp = {'RA-SAGE top-k': 'Top-k by RA-SAGE score', 'Greedy (reference)': 'Greedy on snapshots (reference)'}
rows = [[disp.get(m, m)] + [f'{SP[k][m]:,.0f}' for k in (5, 10, 20, 50)] for m in meths]
table(['Seed selection method', 'k = 5', 'k = 10', 'k = 20', 'k = 50'], rows, [2.6, 0.85, 0.85, 0.85, 0.85], f'Expected campaign reach (users, out of {N:,}) at p = 0.02, measured on 3,000 fresh snapshots.', align=['l', 'c', 'c', 'c', 'c'], bold_rows=(5,), hl_rows=(5,))
figure(f'{FIGDIR}/fig_seeds.png', 6.3, 'Expected reach (% of the network) versus number of seeds for three transmission probabilities.')
figure(f'{FIGDIR}/fig_network.png', 6.1, 'Where the 20 seeds sit in the network (p = 0.02). Nodes are shaded by single-user expected reach; stars mark the selected seeds. (a) The 20 highest-scoring users all lie in one dense community. (b) With the diversity discount, seeds spread across communities.')
nv, gd20, gr20 = SP[20]['RA-SAGE top-k'], SP[20]['GNN-GDS (ours)'], SP[20]['Greedy (reference)']
para(f'**The top-k trap.** Choosing the 20 users with the highest RA-SAGE scores reaches only {nv:,.0f} users, worse than picking 20 users at random ({SP[20]["Random"]:,.0f}), even though each of those users is individually among the most influential in the network (Figure 9a). They are friends of one another, so after the first one or two seeds the rest add almost nobody new. This is the submodularity of the objective in action: the value of a seed depends on who has already been chosen.')
para(f'**What the diversity discount recovers.** GNN-GDS lifts the same learned scores to {gd20:,.0f} users at k = 20, which is {100*(gd20/nv-1):.0f}% more than the naive selection, {100*(gd20/SP[20]["Random"]-1):.0f}% more than random and {100*gd20/gr20:.0f}% of the greedy reference (Figure 9b). At k = 50 it reaches {SP[50]["GNN-GDS (ours)"]:,.0f} users, {100*SP[50]["GNN-GDS (ours)"]/SP[50]["Greedy (reference)"]:.0f}% of the reference.')
rows = []
for k in (10, 20, 50):
    rows.append([f'k = {k}'] + [f'{100*seeds[p]["spread"][k]["GNN-GDS (ours)"]/seeds[p]["spread"][k]["Greedy (reference)"]:.0f}%' for p in (0.01, 0.02, 0.03)] + [f'{100*seeds[0.02]["spread"][k]["PageRank"]/seeds[0.02]["spread"][k]["Greedy (reference)"]:.0f}%'])
table(['Budget', 'GNN-GDS, p = 0.01', 'GNN-GDS, p = 0.02', 'GNN-GDS, p = 0.03', 'PageRank, p = 0.02'], rows, [0.9, 1.35, 1.35, 1.35, 1.35], 'Reach as a percentage of the greedy reference.', align=['l', 'c', 'c', 'c', 'c'])
para(f'**Where GNN-GDS does not win.** The simple baselines are strong. PageRank, although a poor individual predictor, is an excellent seed-set heuristic because its top users are global hubs spread across different communities; it reaches {SP[20]["PageRank"]:,.0f} users at k = 20 against {gd20:,.0f} for GNN-GDS. Degree-based heuristics also match or beat GNN-GDS at small budgets (k = 5 and 10 at p = 0.02) and at most budgets at p = 0.01. GNN-GDS overtakes DegreeDiscount only for larger budgets at p = 0.02 and 0.03 (for example {SP[50]["GNN-GDS (ours)"]:,.0f} against {SP[50]["Degree-Discount"]:,.0f} users at k = 50, p = 0.02). The greedy reference is best everywhere. Learned scores plus a discount are therefore useful and cheap, but they are not a replacement for either a good graph heuristic or a simulation-based greedy search on a network of this size.')

# ============ 7 ============
h1('7  Real-World Impact, Limitations and Future Work')
h2('7.1  What this means for a marketing team')
bullets([f'**Budget.** Targeting 20 users (0.5% of the network) with diversity-aware selection is expected to reach about {gd20:,.0f} people ({100*gd20/N:.0f}%), compared with {nv:,.0f} ({100*nv/N:.0f}%) if the team simply contacts the 20 "top-scored" influencers. Choosing influencers for complementary audiences, not just individual strength, is worth roughly {100*(gd20/nv-1):.0f}% more reach for the same spend.', f'**Cost of getting started.** Because 10 to 20% of users with simulated outcomes are enough for ρ ≈ {fe[0.2][0]:.2f}, the labelling effort can be limited and the model applied to everyone else. For a platform with millions of users this is the difference between a feasible and an infeasible pipeline.', '**Scenario planning.** Different assumed share probabilities change who is best to target (Figure 7 and Appendix A). Teams should run the analysis for a range of p rather than a single guess.', '**Decision support, not automation.** The model ranks structural reach. Real influencer choices also depend on audience fit, brand safety, cost per influencer and content quality, which are outside the graph used here.'])
h2('7.2  Limitations')
bullets(['**Simulated diffusion.** Cascades are generated from a model with a uniform transmission probability, not observed from real sharing behaviour. The results demonstrate that a GNN can learn this process, not that p = 0.02 describes real consumers.', '**Friendship, not follower, network.** ego-Facebook is an undirected friendship graph with ten ego networks, so it is smaller and more clustered than a typical influencer platform. Findings may not transfer to directed, much larger networks.', '**Surrogate benefit depends on simulator cost.** With this percolation-based simulator, labelling every user and running greedy takes under a second, so the surrogate is not faster here. Its value appears with expensive diffusion models (time-dependent, topic-aware or agent-based) and with networks too large to simulate exhaustively. We did not test those regimes.', '**Single network and modest improvements.** Everything was run on one graph. The ranking-loss gain is small and gradient boosting is nearly as accurate as the GNNs.', '**Greedy parameters tuned per budget.** GNN-GDS needs a small tuning simulation (500 snapshots), whereas PageRank and DegreeDiscount need none.'])
h2('7.3  Future work')
bullets(['Replace simulated cascades with observed retweet or share cascades on real data, and learn edge-specific transmission probabilities.', 'Move to heterogeneous graphs (users, brands, hashtags, posts) and add node attributes such as interests and engagement history.', 'Learn the //marginal// gain of a candidate given the current seed set (a set-aware GNN or reinforcement-learning policy) instead of using a hand-set discount.', 'Add cost-aware and fairness constraints, such as influencer fees and coverage of different customer segments, and validate with an A/B test.'])
h2('7.4  Ethical considerations')
para('Influence modelling relies on personal social connections. Any deployment would need user consent, data minimisation and transparency about how people are targeted, and campaigns should disclose sponsored content. The data used here is publicly released and anonymised.')

# ============ 8 ============
h1('8  Conclusion')
para(f'A GNN trained on simulated outcomes for a minority of users can rank all users by influence with a rank correlation of about {ra["rho"][0]:.2f}, far above degree-based and PageRank rankings, and it reaches this accuracy from three raw structural features. The more important lesson for marketing is that accurate individual scores do not by themselves yield a good campaign: selecting the highest-scoring users produced the worst campaign among the informed methods we tested because their audiences overlap. A simple diversity discount fixes most of this problem and brings the learned approach to {100*gd20/gr20:.0f}% of a simulation-based greedy reference at k = 20, although PageRank and greedy search remain stronger on this network. The work suggests that GNN surrogates are most promising where simulation is expensive, and that the next step is to test them on real cascades and richer diffusion models.')

# ============ refs ============
h1('References')
refs = ['D. Kempe, J. Kleinberg and É. Tardos, "Maximizing the spread of influence through a social network," in Proc. 9th ACM SIGKDD Int. Conf. on Knowledge Discovery and Data Mining (KDD), 2003, pp. 137–146.',
 'J. Leskovec, A. Krause, C. Guestrin, C. Faloutsos, J. VanBriesen and N. Glance, "Cost-effective outbreak detection in networks," in Proc. KDD, 2007, pp. 420–429.',
 'W. Chen, Y. Wang and S. Yang, "Efficient influence maximization in social networks," in Proc. KDD, 2009, pp. 199–208.',
 'T. N. Kipf and M. Welling, "Semi-supervised classification with graph convolutional networks," in Proc. Int. Conf. on Learning Representations (ICLR), 2017.',
 'W. L. Hamilton, R. Ying and J. Leskovec, "Inductive representation learning on large graphs," in Advances in Neural Information Processing Systems (NeurIPS), 2017.',
 'P. Veličković, G. Cucurull, A. Casanova, A. Romero, P. Liò and Y. Bengio, "Graph attention networks," in Proc. ICLR, 2018.',
 'J. McAuley and J. Leskovec, "Learning to discover social circles in ego networks," in Advances in Neural Information Processing Systems (NIPS), 2012.',
 'L. Page, S. Brin, R. Motwani and T. Winograd, "The PageRank citation ranking: Bringing order to the web," Stanford InfoLab Technical Report, 1999.',
 'M. E. J. Newman, "Spread of epidemic disease on networks," Physical Review E, vol. 66, no. 1, 016128, 2002.',
 'Y. Li, J. Fan, Y. Wang and K.-L. Tan, "Influence maximization on social graphs: A survey," IEEE Transactions on Knowledge and Data Engineering, vol. 30, no. 10, pp. 1852–1872, 2018.',
 'J. Leskovec and A. Krevl, "SNAP Datasets: Stanford large network dataset collection," 2014. [Online]. Available: http://snap.stanford.edu/data',
 'C. Burges et al., "Learning to rank using gradient descent," in Proc. Int. Conf. on Machine Learning (ICML), 2005.']
for i, t in enumerate(refs, 1):
    p = para(f'[{i}]  {t}', 'left', 11, after=3); p.paragraph_format.left_indent = Inches(0.35); p.paragraph_format.first_line_indent = Inches(-0.35)

# ============ appendix ============
h1('Appendix A  Tuned Discount Parameters and Timing')
rows = []
for p_ in (0.01, 0.02, 0.03):
    rows.append([f'p = {p_}'] + [f'({seeds[p_]["gds_params"][k][0]}, {seeds[p_]["gds_params"][k][1]})' for k in (5, 10, 20, 30, 50)])
table(['Setting', 'k = 5', 'k = 10', 'k = 20', 'k = 30', 'k = 50'], rows, [1.0, 1.0, 1.0, 1.0, 1.0, 1.0], 'Discount factors (f₁, f₂) selected for GNN-GDS on the tuning snapshots.', align=['l', 'c', 'c', 'c', 'c', 'c'])
para(f'Computation times on 2 CPU cores: selecting 50 seeds with GNN-GDS from precomputed scores takes about {seeds[0.02]["times"]["gds_s"]:.2f} s; snapshot-based greedy selection for 50 seeds takes about {seeds[0.02]["times"]["greedy_s"]:.1f} s (500 snapshots); training one GraphSAGE fold takes about {R["GraphSAGE"]["train_s"]:.0f} s. At this network size the exact greedy search is not a bottleneck, which is why we describe the surrogate\'s benefit as conditional on simulator cost (Section 7.2).')

doc.save(str(REPORT / 'GNN_Influencer_Marketing_Case_Study.docx')); print('saved', CAP)
