#!/usr/bin/env bash
# Re-run the whole study from the raw edge list. About 25 minutes on 2 CPU cores.
# Every stage can also be run on its own (see README).
set -euo pipefail
cd "$(dirname "$0")/src"

python graph_stats.py        # network statistics            -> results/stats.json
python run_main.py           # heuristics, GBM, MLP, GCN, GraphSAGE, RA-SAGE, ablations,
                             # label efficiency, transfer     -> results/*.pkl   (~17 min)
python run_gat.py            # GAT at p = 0.02                -> results/gat_results.json (~7 min)
python run_seeds.py          # seed-set selection experiment  -> results/seeds.pkl (~2 min)
python layout.py             # force-directed layout for the network figure (~1 min)
python fig_diagrams.py       # pipeline + architecture diagrams
python figs_results.py       # all result figures             -> figures/
python build_report.py       # Word report                    -> report/
